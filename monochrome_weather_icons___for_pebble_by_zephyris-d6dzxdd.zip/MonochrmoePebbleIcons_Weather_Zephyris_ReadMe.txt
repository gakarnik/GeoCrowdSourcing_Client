These are a set of monochrome weather icons designed for Pebble. This ZIP file includes the source .svg file, an anti-aliased black and white version of the icons, and 64px and 32px sized white or black monochrome versions of the icons.

These icons are free to use under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported license:
http://creativecommons.org/licenses/by-nc-sa/3.0/

Roughly speaking you can use these icons for any project, so long as it is not commercial, you credit me, and you share any modifications you make to these icons freely. I suggest my name (Richard Wheeler/Zephyris) and link to my website (www.richardwheeler.net) is suitable credit.